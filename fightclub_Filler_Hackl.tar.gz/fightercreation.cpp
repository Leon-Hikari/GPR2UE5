/**
Grundlagen der Programmierung 2
�bung 5
Gruppe: Johannes Hackl, Christian Filler
*/

#include <string>
#include <iostream>
#include "fighters.h"
#include "fightclub.h"

using namespace std;


//MEN� ZUR AUSWAHL VON TYP UND NAMEN EINES NEUEN K�MPFERS
void createFighter()
{
    string inputS;
    int inputI;


    {
        cout << endl << "What kind of fighter is it?" <<
        endl << " 1) Warrior: A brave fighter that sometimes attacks very strongly" <<
        endl << " 2) Ninja: Moving so fast that they can sometimes escape an attack but still launch a counterattack" <<
        endl << " 3) Tank: Someone who can take much more damage than everyone else" <<
        endl << " 4) Pink Fluffy Unicorn: It dances on rainbows" <<
        endl << " 5) Don't register any new fighter" <<
        endl << endl;

        getline(cin, inputS);
        inputI=inputS[0]-'0';

        if (inputI>0 && inputI<=4)
        {
            cout << endl << "I see. And under what name should I register this fighter?" << endl;
            getline (cin, inputS);

            //�berpr�fen ob Name bereits vorhanden
            while (mapfind(inputS) == true)
            {
                cout << endl << "I'm sorry, another fighter already uses this name. Please choose another one." << endl;
                getline (cin, inputS);
            }
        }

        switch (inputI)
        {
            case 1: createdFighters[inputS] = new warrior(inputS);
                    break;
            case 2: createdFighters[inputS] = new ninja(inputS);
                    break;
            case 3: createdFighters[inputS] = new tank(inputS);
                    break;
            case 4: createdFighters[inputS] = new pinkFluffyUnicorn(inputS);
                    break;
            case 5: return;
                    break;
            default:    wrongInputNumber();
                        break;
        }

        cout << "The fighter with the name " << inputS << " was successfully registered." <<
        endl << "He has " << createdFighters[inputS]->getLifePoints() << " lifepoints, " << createdFighters[inputS]->getOffensePoints() << " offensepoints and " << createdFighters[inputS]->getDefensePoints() << " defensepoints." << endl << endl;


    }
    return;
}

void destroyFighters() {
	for (map <string, fighter*>::iterator i = createdFighters.begin(); i != createdFighters.end(); i++) {
		delete i->second;
	}
	createdFighters.clear();
}

void deleteFighter(fighter* fighter1)
{
    //cout << "Number of fighters before deletion: " << createdFighters.size() << endl;
    createdFighters.erase(fighter1->mname);
    delete fighter1;
    fighter1=nullptr;
    //cout << "Number of fighters after deletion: " << createdFighters.size() << endl;
}

void deleteKOedFighter(fighter* fighter1) {
	if (fighter1->getLifePoints() <= 0)
	{
        deleteFighter(fighter1);
	}
}

void retireFighter()
{
    string input;
    cout << "Which fighter do you wish to withdraw from the tournament registration?" << endl;
    getline (cin, input);
    if(mapfind(input) == true)
    {
        deleteFighter(createdFighters[input]);
        cout << "We have withdrawn the registration of " << input << endl << endl;
    }
    else
    {
        cout << "We don't have anyone registered under this name." << endl << endl;
    }
}
